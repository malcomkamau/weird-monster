# weird-monster
Weird Monster - html, css and js
# Demo
* One: <a href="https://tuberboy.github.io/weird-monster/one.html" target="_blank">Click Here</a>
* Two: <a href="https://tuberboy.github.io/weird-monster/two.html" target="_blank">Click Here</a>
* Three: <a href="https://tuberboy.github.io/weird-monster/three.html" target="_blank">Click Here</a>
* Four: <a href="https://tuberboy.github.io/weird-monster/four.html" target="_blank">Click Here</a>
* Five: <a href="https://tuberboy.github.io/weird-monster/five.html" target="_blank">Click Here</a>
<img src="Screenshot.png"/>

# Spider
<img src="Screenshot-Spider.png"/>

* Demo: <a href="https://tuberboy.github.io/weird-monster/spider.html" target="_blank">Click Here</a>

# Hourse
<img src="Screenshot-Hourse.png"/>

* Demo: <a href="https://tuberboy.github.io/weird-monster/hourse.html" target="_blank">Click Here</a>

# Dragon
<img src="Screenshot-Dragon.png"/>

* Demo: <a href="https://tuberboy.github.io/weird-monster/dragon.html" target="_blank">Click Here</a>

# Curly Cursor
<img src="Screenshot-CurlyCursor.png"/>

* Demo: <a href="https://tuberboy.github.io/weird-monster/curlycursor.html" target="_blank">Click Here</a>

# Neon Curly Cursor
<img src="Screenshot-NeonCurlyCursor.png"/>

* Demo: <a href="https://tuberboy.github.io/weird-monster/neoncurlycursor.html" target="_blank">Click Here</a>

# Canvas Text
<img src="Screenshot-CanvasText.png"/>

* Demo: <a href="https://tuberboy.github.io/weird-monster/canvastext.html" target="_blank">Click Here</a>

# Attraction
<img src="Screenshot-Attraction.png"/>

* Demo: <a href="https://tuberboy.github.io/weird-monster/attraction.html" target="_blank">Click Here</a>

# Blue (Triangles) dragon
<img src="Screenshot-blueTD.png"/>

* Demo: <a href="https://tuberboy.github.io/weird-monster/bluetringlesdragon.html" target="_blank">Click Here</a>

# Monster Electrico
<img src="Screenshot-Electrico.png"/>

* Demo: <a href="https://tuberboy.github.io/weird-monster/monsterelectrico.html" target="_blank">Click Here</a>

# Shark Monster
<img src="shark/Screenshot-Shark.png"/>

* Demo: <a href="https://tuberboy.github.io/weird-monster/shark" target="_blank">Click Here</a>

# Octopus
<img src="Screenshot-Octopus.png"/>

* Demo: <a href="https://tuberboy.github.io/weird-monster/octopus.html" target="_blank">Click Here</a>

# WebGL Ghost
<img src="Screenshot-Ghost.png"/>

* Demo: <a href="https://tuberboy.github.io/weird-monster/ghost.html" target="_blank">Click Here</a>
